# Archive of the Awesome Generative AI list

These projects are not active anymore in generative AI.

- [Kite](https://www.kite.com/) - Kite adds AI powered code completions to your code editor, giving developers superpowers. [Farewell message](https://www.kite.com/blog/product/kite-is-saying-farewell/). [Code](https://github.com/kiteco).
- [Pygma](https://twitter.com/pygma_app) - Turn Figma designs into high-quality code.
- [Coqui](https://coqui.ai/) - Coqui is dedicated to open speech technology and to serving as the hub where speech researchers, developers, and practitioners congregate.
- [Contenda](https://contenda.co/) - Create the content your audience wants, from content you've already made.
